// generated from rosidl_generator_c/resource/idl.h.em
// with input from perception_ros2_msg:msg/LidarFrameMsg.idl
// generated code does not contain a copyright notice

#ifndef PERCEPTION_ROS2_MSG__MSG__LIDAR_FRAME_MSG_H_
#define PERCEPTION_ROS2_MSG__MSG__LIDAR_FRAME_MSG_H_

#include "perception_ros2_msg/msg/lidar_frame_msg__struct.h"
#include "perception_ros2_msg/msg/lidar_frame_msg__functions.h"
#include "perception_ros2_msg/msg/lidar_frame_msg__type_support.h"

#endif  // PERCEPTION_ROS2_MSG__MSG__LIDAR_FRAME_MSG_H_
