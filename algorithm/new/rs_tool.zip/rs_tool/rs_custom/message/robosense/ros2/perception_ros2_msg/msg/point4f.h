// generated from rosidl_generator_c/resource/idl.h.em
// with input from perception_ros2_msg:msg/Point4f.idl
// generated code does not contain a copyright notice

#ifndef PERCEPTION_ROS2_MSG__MSG__POINT4F_H_
#define PERCEPTION_ROS2_MSG__MSG__POINT4F_H_

#include "perception_ros2_msg/msg/point4f__struct.h"
#include "perception_ros2_msg/msg/point4f__functions.h"
#include "perception_ros2_msg/msg/point4f__type_support.h"

#endif  // PERCEPTION_ROS2_MSG__MSG__POINT4F_H_
