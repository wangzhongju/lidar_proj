// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PERCEPTION_ROS2_MSG__MSG__LANE_HPP_
#define PERCEPTION_ROS2_MSG__MSG__LANE_HPP_

#include "perception_ros2_msg/msg/lane__struct.hpp"
#include "perception_ros2_msg/msg/lane__traits.hpp"

#endif  // PERCEPTION_ROS2_MSG__MSG__LANE_HPP_
