LZ4 Version: 1.9.3
URL: https://github.com/lz4/lz4/tree/v1.9.3
